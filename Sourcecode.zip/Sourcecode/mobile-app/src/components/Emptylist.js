import { View, Text } from 'react-native'
import React from 'react'

const Emptylist = () => {
  return (
    <View>
      <Text>Emptylist</Text>
    </View>
  )
}

export default Emptylist